import { posts } from '../data/posts';
import { PostCard } from '../components/PostCard';
export default function ArtistsPage() {
  const filtered = posts.filter((p) => p.category === 'Artists');
  return <main className="mx-auto max-w-7xl px-5 py-16"><h1 className="mb-8 text-5xl font-black">Artists</h1><div className="grid gap-6 md:grid-cols-3">{filtered.map((p) => <PostCard key={p.slug} post={p} />)}</div></main>;
}
