export default function ContactPage() {
  return <main className="mx-auto max-w-3xl px-5 py-20"><h1 className="text-5xl font-black">Contact</h1><p className="mt-6 text-lg leading-8 text-zinc-300">For submissions, premieres and collaborations, contact us at <strong className="text-white">hello@yourdomain.com</strong>.</p></main>;
}
