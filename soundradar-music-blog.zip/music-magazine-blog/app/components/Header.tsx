import Link from 'next/link';
import { Music2 } from 'lucide-react';

const nav = [
  ['Reviews', '/reviews'],
  ['Festivals', '/festivals'],
  ['Artists', '/artists'],
  ['Contact', '/contact'],
];

export function Header() {
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-black/40 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <Link href="/" className="flex items-center gap-3 font-black tracking-tight">
          <span className="grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br from-violet-500 to-sky-400 shadow-lg shadow-violet-500/30">
            <Music2 size={21} />
          </span>
          <span className="text-xl">SoundRadar</span>
        </Link>
        <nav className="hidden items-center gap-7 text-sm text-zinc-300 md:flex">
          {nav.map(([label, href]) => <Link className="transition hover:text-white" key={href} href={href}>{label}</Link>)}
        </nav>
      </div>
    </header>
  );
}
