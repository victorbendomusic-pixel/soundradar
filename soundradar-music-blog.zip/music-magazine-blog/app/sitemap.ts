import { MetadataRoute } from 'next';
import { posts } from './data/posts';

export default function sitemap(): MetadataRoute.Sitemap {
  const baseUrl = 'https://yourdomain.com';
  return [
    { url: baseUrl, lastModified: new Date() },
    { url: `${baseUrl}/reviews`, lastModified: new Date() },
    { url: `${baseUrl}/festivals`, lastModified: new Date() },
    { url: `${baseUrl}/artists`, lastModified: new Date() },
    ...posts.map((post) => ({ url: `${baseUrl}/blog/${post.slug}`, lastModified: new Date(post.date) })),
  ];
}
