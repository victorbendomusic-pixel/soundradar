import Image from 'next/image';
import Link from 'next/link';
import { Post } from '@/app/data/posts';

export function PostCard({ post, large = false }: { post: Post; large?: boolean }) {
  return (
    <Link href={`/blog/${post.slug}`} className="group block overflow-hidden rounded-[2rem] border border-white/10 bg-white/[.04] shadow-2xl shadow-black/30 transition hover:-translate-y-1 hover:border-violet-400/50">
      <div className={`relative ${large ? 'h-80' : 'h-56'} overflow-hidden`}>
        <Image src={post.image} alt={post.title} fill className="object-cover transition duration-700 group-hover:scale-105" />
        <div className="absolute inset-0 bg-gradient-to-t from-black via-black/30 to-transparent" />
        <span className="absolute left-5 top-5 rounded-full bg-white/10 px-4 py-2 text-xs font-bold uppercase tracking-[.2em] backdrop-blur">{post.category}</span>
      </div>
      <div className="p-6">
        <p className="mb-3 text-xs uppercase tracking-[.25em] text-violet-300">{post.date} · {post.readTime}</p>
        <h3 className={`${large ? 'text-3xl' : 'text-2xl'} font-black leading-tight group-hover:text-violet-200`}>{post.title}</h3>
        <p className="mt-4 text-zinc-400">{post.excerpt}</p>
      </div>
    </Link>
  );
}
