import type { Metadata } from 'next';
import './globals.css';
import { Header } from './components/Header';
import { Footer } from './components/Footer';

export const metadata: Metadata = {
  metadataBase: new URL('https://yourdomain.com'),
  title: {
    default: 'SoundRadar | New Music, Reviews and Festivals',
    template: '%s | SoundRadar',
  },
  description: 'A modern music magazine covering new artists, reviews, festivals and cinematic sounds.',
  openGraph: {
    title: 'SoundRadar',
    description: 'New music, reviews, festivals and independent artists.',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="noise">
        <Header />
        {children}
        <Footer />
      </body>
    </html>
  );
}
