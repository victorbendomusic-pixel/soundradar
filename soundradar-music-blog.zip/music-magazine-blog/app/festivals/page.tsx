import { posts } from '../data/posts';
import { PostCard } from '../components/PostCard';
export default function FestivalsPage() {
  const filtered = posts.filter((p) => p.category === 'Festivals');
  return <main className="mx-auto max-w-7xl px-5 py-16"><h1 className="mb-8 text-5xl font-black">Festivals</h1><div className="grid gap-6 md:grid-cols-3">{filtered.map((p) => <PostCard key={p.slug} post={p} />)}</div></main>;
}
