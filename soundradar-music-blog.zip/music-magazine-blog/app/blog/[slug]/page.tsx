import Image from 'next/image';
import { notFound } from 'next/navigation';
import { posts } from '@/app/data/posts';

export function generateStaticParams() {
  return posts.map((post) => ({ slug: post.slug }));
}

export function generateMetadata({ params }: { params: { slug: string } }) {
  const post = posts.find((item) => item.slug === params.slug);
  if (!post) return {};
  return { title: post.title, description: post.excerpt };
}

export default function BlogPost({ params }: { params: { slug: string } }) {
  const post = posts.find((item) => item.slug === params.slug);
  if (!post) notFound();

  return (
    <main className="mx-auto max-w-4xl px-5 py-14">
      <p className="text-sm font-bold uppercase tracking-[.3em] text-violet-300">{post.category}</p>
      <h1 className="mt-5 text-5xl font-black leading-tight tracking-tight md:text-7xl">{post.title}</h1>
      <p className="mt-6 text-xl leading-8 text-zinc-300">{post.excerpt}</p>
      <p className="mt-5 text-sm text-zinc-500">{post.date} · {post.readTime}</p>
      <div className="relative mt-10 h-[420px] overflow-hidden rounded-[2rem] border border-white/10">
        <Image src={post.image} alt={post.title} fill className="object-cover" />
      </div>
      <article className="article-content mt-12 text-lg">
        {post.content.map((paragraph, index) => <p key={index}>{paragraph}</p>)}
      </article>
    </main>
  );
}
