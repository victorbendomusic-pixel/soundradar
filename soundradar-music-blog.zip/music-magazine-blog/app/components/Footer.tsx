export function Footer() {
  return (
    <footer className="mt-24 border-t border-white/10 px-5 py-10 text-center text-sm text-zinc-500">
      <p>© 2026 SoundRadar. Music reviews, festivals and independent artists.</p>
    </footer>
  );
}
