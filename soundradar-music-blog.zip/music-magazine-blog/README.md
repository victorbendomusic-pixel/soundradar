# SoundRadar Music Blog

Modern Next.js music magazine template.

## Run locally
```bash
npm install
npm run dev
```

## Edit articles
Open `app/data/posts.ts` and add/edit posts.

## Deploy
Upload this folder to GitHub, then import the repository on Vercel.

## Before publishing
Replace `https://yourdomain.com` with your real domain in:
- `app/layout.tsx`
- `app/sitemap.ts`
- `app/robots.ts`
