import Link from 'next/link';
import { ArrowRight, Sparkles } from 'lucide-react';
import { featuredPost, posts } from './data/posts';
import { PostCard } from './components/PostCard';

export default function Home() {
  return (
    <main className="mx-auto max-w-7xl px-5">
      <section className="grid min-h-[78vh] items-center gap-10 py-16 lg:grid-cols-[1.05fr_.95fr]">
        <div>
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-violet-400/30 bg-violet-400/10 px-4 py-2 text-sm text-violet-200">
            <Sparkles size={16} /> Independent music magazine
          </div>
          <h1 className="max-w-4xl text-5xl font-black leading-[.95] tracking-tight md:text-7xl lg:text-8xl">
            Discover music before it becomes noise.
          </h1>
          <p className="mt-7 max-w-2xl text-lg leading-8 text-zinc-300">
            Reviews, festival previews and artist stories with a cinematic editorial style.
          </p>
          <div className="mt-9 flex flex-wrap gap-4">
            <Link href="/reviews" className="inline-flex items-center gap-2 rounded-full bg-white px-6 py-3 font-bold text-black transition hover:bg-violet-200">
              Read reviews <ArrowRight size={18} />
            </Link>
            <Link href="/festivals" className="inline-flex items-center gap-2 rounded-full border border-white/15 px-6 py-3 font-bold text-white transition hover:bg-white/10">
              Explore festivals
            </Link>
          </div>
        </div>
        <PostCard post={featuredPost} large />
      </section>

      <section className="py-12">
        <div className="mb-8 flex items-end justify-between gap-5">
          <div>
            <p className="text-sm font-bold uppercase tracking-[.3em] text-violet-300">Latest stories</p>
            <h2 className="mt-3 text-4xl font-black">Fresh from the magazine</h2>
          </div>
        </div>
        <div className="grid gap-6 md:grid-cols-3">
          {posts.map((post) => <PostCard key={post.slug} post={post} />)}
        </div>
      </section>
    </main>
  );
}
