export type Post = {
  slug: string;
  title: string;
  excerpt: string;
  category: 'Reviews' | 'Festivals' | 'Artists';
  date: string;
  image: string;
  readTime: string;
  content: string[];
};

export const posts: Post[] = [
  {
    slug: 'lucid-whisper-unknowingly-happy',
    title: 'Lucid Whisper Turns Stillness Into a Cinematic Lo-Fi Memory',
    excerpt: 'A delicate, nostalgic track shaped by atmosphere, warmth and emotional restraint.',
    category: 'Reviews',
    date: '2026-05-31',
    image: 'https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?q=80&w=1600&auto=format&fit=crop',
    readTime: '4 min read',
    content: [
      'Lucid Whisper creates a sound world that feels intimate, cinematic and emotionally suspended. The track does not try to overwhelm the listener; instead, it relies on warmth, space and quiet detail.',
      'The production is minimal but intentional. Soft textures, nostalgic tones and a delicate rhythm create the feeling of a memory slowly returning. It is lo-fi, but not anonymous. It feels curated and deeply personal.',
      'What makes the song work is its restraint. Every element has room to breathe, allowing the atmosphere to become the main emotional voice of the piece.',
      'For listeners who appreciate calm, immersive and reflective music, this release feels like a small cinematic escape.'
    ],
  },
  {
    slug: 'horizon-festival-2026-guide',
    title: 'Horizon Festival 2026: Line-Up, Atmosphere and Everything to Know',
    excerpt: 'A complete preview of one of the most exciting electronic music events of the season.',
    category: 'Festivals',
    date: '2026-05-30',
    image: 'https://images.unsplash.com/photo-1501386761578-eac5c94b800a?q=80&w=1600&auto=format&fit=crop',
    readTime: '5 min read',
    content: [
      'Horizon Festival 2026 is shaping up as a major destination for fans of electronic music, immersive stages and high-energy live experiences.',
      'The festival identity is built around more than music. Visual production, crowd energy, location and community all contribute to an atmosphere designed for people who want a full weekend experience.',
      'From international acts to emerging names, the line-up gives the event a wide appeal. It is the kind of festival that can attract both dedicated dance music fans and casual listeners looking for a memorable summer event.',
      'With the right mix of music, design and audience, Horizon Festival has the potential to become a strong name on the European festival calendar.'
    ],
  },
  {
    slug: 'stellaghost-emptiness',
    title: 'StellaGhost Introduces a Shadowy Cinematic Debut With EMPTINESS',
    excerpt: 'A debut shaped by atmosphere, emotional tension and dark alternative energy.',
    category: 'Artists',
    date: '2026-05-28',
    image: 'https://images.unsplash.com/photo-1511379938547-c1f69419868d?q=80&w=1600&auto=format&fit=crop',
    readTime: '4 min read',
    content: [
      'StellaGhost arrives with a debut that feels intentionally cinematic, dark and emotionally charged. EMPTINESS is not simply a collection of sounds; it feels like a world being introduced.',
      'The project blends alternative rock energy with atmospheric production choices. The result is dramatic without becoming excessive, emotional without losing control.',
      'What stands out is the sense of identity. StellaGhost appears interested in creating a recognizable universe, not just releasing individual tracks.',
      'As a debut, EMPTINESS gives the listener a clear first impression: shadow, tension, vulnerability and ambition.'
    ],
  },
];

export const featuredPost = posts[0];
